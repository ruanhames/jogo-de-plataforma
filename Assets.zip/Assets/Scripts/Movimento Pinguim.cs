using UnityEngine;

public class MovimentoPinguim : MonoBehaviour
{
    public float velocidade;
   private Rigidbody2D rb;
    private Vector2 direcao;
    private bool noChao=false;

    
   void OnCollisionEnter2D(Collision2D collision) {

    if (collision.gameObject.CompareTag("Chão")) {
        noChao = true;
    }

    if (collision.gameObject.CompareTag("Inimigo")) {

        Destroy(gameObject);
    }
   

     if (collision.gameObject.CompareTag("Item")) {

        Destroy(collision.gameObject);
    }
   }




    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
      rb = GetComponent<Rigidbody2D>();
        
        
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.Space) && noChao) {
                rb.linearVelocity=new Vector2(rb.linearVelocity.x, 10f);
                noChao=false;


        }
        float horizontal = Input.GetAxisRaw("Horizontal")*velocidade;
        Vector2 nova = transform.position;
        nova.x += horizontal;
        transform.position=nova;



    }

   
}

