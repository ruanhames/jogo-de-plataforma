using UnityEngine;

public class ColisaoMoedaInimigo : MonoBehaviour
{

    
   

   void OnCollisionEnter2D(Collision2D collision) {
    if (collision.gameObject.CompareTag("Inimigo")) {

        Destroy(gameObject);
    }
   

     if (collision.gameObject.CompareTag("Item")) {

        Destroy(collision.gameObject);
    }
   }








    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
